import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.integrate import trapezoid
from scipy.signal import savgol_filter
from matplotlib.backends.backend_pdf import PdfPages
import re
#Recordar quitar el '#' que llama a una función para poder ver los resultados.

#Tarea_1_Parte_1_Tubo_Rayos_X

#Parte 1.a)



#Primero se lee el csv y se guardan los datos en un dataframe de pandas

df = pd.read_csv('Rhodium.csv')

#Seguidamente se crean dos dataframes vacios. dataframes = df, intensidad = itd, gradiente = grad.

df_itd_grad_2 = pd.DataFrame()
df_itd_grad = pd.DataFrame()

#Del df original se aplica el gradiente dos veces a la columna de 'Intensidad'.

itd = df['Intensity (mJy)']
itd_grad = np.gradient(itd)
itd_grad_2 = abs(np.gradient(itd_grad))

#El primer df recibe el doble gradiente.

df_itd_grad_2['Intensity (mJy)'] = itd_grad_2

#El segundo df recibe el primer gradiente.
#Cada dato anomalo se puede considerar un pico debido a su estructura por lo que su primera derivada es 0.

df_itd_grad['Intensity (mJy)'] = itd_grad

#Se filtran los datos del primer df.
#La segunda derivada se requiere para ver los cambios de los picos y asi no eliminar valores
#que no son anomalos pero que su primera derivada es 0.

df_itd_grad_2_fil = df_itd_grad_2.loc[df_itd_grad_2['Intensity (mJy)'] > 0.001]



def limpieza():
    
    #Se crea una copia del df original y la variable que guardara datos eliminados.
    
    n_eliminados = 0
    dfc = df.copy()
    
    #Se buscan en el primer df filtrado los indices de cada dato.
    
    for i in df_itd_grad_2_fil['Intensity (mJy)']:
    
        ind = df_itd_grad_2_fil.index[df_itd_grad_2_fil['Intensity (mJy)'] == i]

    #Debido a que los datos antes y despues de un pico tienden a ser iguales,
    #Se busca que el dato del indice sea solo uno.

        if ind.size == 1:
            
    #Se encuentra en el segundo df el dato asociado al indice y se extrae.

            val = df_itd_grad.iloc[ind]
            val = val.iat[0,0]

    #Se pone un limite arbitrario que permite eliminar los picos anomalos que siempre son 0 
    #E impedir que se lleve valores de los dos picos grandes u otros. Luego se eliminan.

            if val <= 0.001:
        
                dfc = dfc.drop(ind,axis=0)
                n_eliminados += 1
                
    #Finalmente se imprimen el número de datos eliminados
    #Además, se entrega un df igual al original sin los datos anomalos con indices reiniciados.   

    print(f'1.a) Número de datos eliminados: {n_eliminados}')
    dfc = dfc.reset_index(drop=True)
    return dfc

def limpieza_pdf(df1):
    
    #Se producen las graficas y el pdf.
    
    with PdfPages('limpieza.pdf') as pdf:
       plt.figure(figsize=(6.5, 5))
       plt.plot(df['Wavelength (pm)'], df['Intensity (mJy)'])
       plt.title('Antes')
       plt.xlabel('Wavelength (pm)')
       plt.ylabel('Intensity (mJy)')
       pdf.savefig()
       plt.close()
       
       plt.figure(figsize=(6.5, 5))
       plt.plot(df1['Wavelength (pm)'], df1['Intensity (mJy)'])
       plt.title('Después')
       plt.xlabel('Wavelength (pm)')
       plt.ylabel('Intensity (mJy)')
       pdf.savefig()
       plt.close()
       
#limpieza_pdf(limpieza())  





#Parte 1.b)

def picos_y_espectro(dfc):
    
    #Se crea una copia del df limpiado y, mediante inspección visual de los valores,
    #Se recortan los valores en los cuales se ubican los dos picos grandes.

    df1 = dfc.copy()
    df1 = dfc.loc[dfc['Wavelength (pm)'] > 70]
    df1 = df1.loc[df1['Wavelength (pm)'] < 115]
    
    #Se recoge el primer y ultimo indice
    
    indi = df1.index[0]
    indf = df1.index[-1]
    
    #Se crea una segunda copia con los dos picos recortados gracias a los indices.
    
    df2 = dfc.copy()
    df2 = df2.drop(df2.index[indi:indf])
    
    #Ahora mismo df1 posee los picos y df2 el espectro con el hueco donde irian los picos.
    #Las columnas de df2 se cambian a listas.
    
    x = df2['Wavelength (pm)'].tolist()
    y = df2['Intensity (mJy)'].tolist()
    
    #Mediante scipy se hace una interpolación de los datos del espectro para llenar el hueco.
    
    y_intp = PchipInterpolator(x,y)
    
    #Se definen nuevos valores de longitud de onda para poner los nuevos valores de intensidad.
    
    x_n = np.linspace(10.2,300,1500)
    y_n = y_intp(x_n)
    
    #Se guardan los arrays en una tupla
    
    tp = (x_n,y_n)
    
    #Se imprime el resumen del metodo y se entrega una tupla de df1 y tp.
    
    resumen = 'Recorte e interpolación de datos.'
    
    print('1.b) Método:', resumen)
    return (df1,tp)

def picos_pdf(tupla):
    
    #Se extraen de la tupla
    
    df1 = tupla[0]
    tp = tupla[1]
    
    #Se producen las graficas y el pdf.
    
    with PdfPages('picos.pdf') as pdf:
       plt.figure(figsize=(6.5, 5))
       plt.plot(df1['Wavelength (pm)'], df1['Intensity (mJy)'])
       plt.title('Picos')
       plt.xlabel('Wavelength (pm)')
       plt.ylabel('Intensity (mJy)')
       pdf.savefig()  # saves the current figure into a pdf page
       plt.close()
       
       plt.figure(figsize=(6.5, 5))
       plt.plot(tp[0], tp[1])
       plt.title('Espectro de Fondo')
       plt.xlabel('Wavelength (pm)')
       plt.ylabel('Intensity (mJy)')
       pdf.savefig()  # saves the current figure into a pdf page
       plt.close()

#picos_pdf(picos_y_espectro(limpieza()))





#Parte 1.c)

def FWHM_y_maximo(tupla):
    
    #Se extraen los datos de los picos de la tupla y se dividen en 2 dfs para cada pico.
    #Además, se extrae el valor maximo de cada pico.
    
    df1 = tupla[0]
    df1p1 = df1[0:round(len(df1)/2)]
    maxp1 = df1p1['Intensity (mJy)'].max(axis=0)
    df1p2 = df1[round(len(df1)/2):-1]
    maxp2 = df1p2['Intensity (mJy)'].max(axis=0)
    
    #Como los picos no son perfectamente continuos el maximo que se extrajo no corresponde
    #al pico ideal para encontrar el FWHM, por lo que se debe buscar el indice correspondiente al maximo.
    #Esto para recortar una parte del pico y suavizar los datos mediante un filtro de savgol.
    #Estos datos suavizados deben tener un maximo que se comporta mejor. Por lo que se escoge tal maximo.
    
    ind_maxp1 = df1p1.index.get_loc(df1p1[df1p1['Intensity (mJy)'] == maxp1].index[0])
    df1p1_s = df1p1[ind_maxp1-15:ind_maxp1+15]
    y = df1p1_s['Intensity (mJy)'].tolist()
    y = savgol_filter(y,2,1)
    maxp1 = y.max()
    
    ind_maxp2 = df1p2.index.get_loc(df1p2[df1p2['Intensity (mJy)'] == maxp2].index[0])
    df1p2_s = df1p2[ind_maxp2-15:ind_maxp2+15]
    y = df1p2_s['Intensity (mJy)'].tolist()
    y = savgol_filter(y,2,1)
    maxp2 = y.max()
    
    #Se hace el mismo procedimiento ya dicho para el espectro excepto la separación en 2 dfs.
    #Esto debido a que solo hay un espectro, aunque aun asi se eliminan datos de la parte derecha que no sirven.
    #Estos datos siendo aquellos que tienden a 0.
    
    df2 = pd.DataFrame()
    dft = tupla[1]
    df2['Wavelength (pm)'] = dft[0]
    df2['Intensity (mJy)'] = dft[1]
    df2 = df2[0:round(len(df2)/2)]
    maxe = df2['Intensity (mJy)'].max(axis=0)
    
    ind_maxe = df2.index.get_loc(df2[df2['Intensity (mJy)'] == maxe].index[0])
    df2_s = df2[ind_maxe-15:ind_maxe+15]
    y = df2_s['Intensity (mJy)'].tolist()
    y = savgol_filter(y,2,1)
    maxe = y.max()
    
    #Para encontrar el FWHM primero se divide el maximo entre 2 y se resta al df.
    #El df restado debe de tener los valores de la mitad del pico cercanos a 0 gracias a la resta.
    #Asi que se divide en 2 los datos del pico para encontrar en cada uno estos 2 valores,
    #Los cuales deben ser los minimos de cada set de datos.
    
    HMP1 = maxp1/2
    locHMP = abs(df1p1['Intensity (mJy)'].sub(HMP1))
    locHMP1 = locHMP[0:round(len(locHMP)/2)]
    locHMP2 = locHMP[round(len(locHMP)/2):-1]
    indminp1 = locHMP1.index[locHMP1 == locHMP1.min()]
    indminp2 = locHMP2.index[locHMP2 == locHMP2.min()]
    
    #De aqui se encuentran las filas de tales valores en el df sin restar.
    
    minp1 = df1p1.loc[indminp1]
    minp2 = df1p1.loc[indminp2]
    
    #Se restan los valores de longitud de onda para hallar finalmente el FWHM.
    #Se le aplica valor absoluto y se redondea. Además de redondearse el maximo para la impresión.
    
    FWHM1 = round(abs(minp1.iat[0,0] - minp2.iat[0,0]),4)
    maxp1 = round(maxp1,4)
    
    #Mismo caso que para el primer pico
    
    HMP2 = maxp2/2
    locHMP = abs(df1p2['Intensity (mJy)'].sub(HMP2))
    locHMP1 = locHMP[0:round(len(locHMP)/2)]
    locHMP2 = locHMP[round(len(locHMP)/2):-1]
    indminp1 = locHMP1.index[locHMP1 == locHMP1.min()]
    indminp2 = locHMP2.index[locHMP2 == locHMP2.min()]
    
    minp1 = df1p2.loc[indminp1]
    minp2 = df1p2.loc[indminp2]
    
    FWHM2 = round(abs(minp1.iat[0,0] - minp2.iat[0,0]),4)
    maxp2 = round(maxp2,4)
    
    #Mismo caso de antes
    
    HME = maxe/2
    locHME = abs(df2['Intensity (mJy)'].sub(HME))
    locHME1 = locHME[0:round(len(locHME)/2)]
    locHME2 = locHME[round(len(locHME)/2):-1]
    indminp1 = locHME1.index[locHME1 == locHME1.min()]
    indminp2 = locHME2.index[locHME2 == locHME2.min()]
    
    minp1 = df2.loc[indminp1]
    minp2 = df2.loc[indminp2]
    
    FWHME = round(abs(minp1.iat[0,0] - minp2.iat[0,0]),4)
    maxe = round(maxe,4)
    
    #Se imprimen los valores hallados para los picos y el espectro
    
    print(f'1.c) Pico 1: {FWHM1} pm, {maxp1} mJy\nPico2: {FWHM2} pm, {maxp2} mJy\nEspectro: {FWHME} pm, {maxe} mJy')
    
#FWHM_y_maximo(picos_y_espectro(limpieza()))





#Parte 1.d)

def integral(tupla):
    
    #Se extraen de la tupla los datos del espectro
    
    x = tupla[1][0]
    y = tupla[1][1]
    
    #Luego de revisar las unidades, se aplica el valor de conversión al SI.
    #De mJy a W/(m^2)(Hz) y  pm a m.
    
    x_SI = x*1e-12
    y_SI = y*1e-29
    
    #Debido a la incertidumbre de la intensidad se debe integrar varias veces
    #para encontrar el promedio de la integral y su incertidumbre.
    
    y_inc = y_SI*0.02
    integrales = np.empty(0)
    
    for i in range(1000):
        
        #Se integra mediante el metodo del trapecio con los valores de intensidad
        #recibiendo una porción aleatoria de su incertidumbre en cada ciclo
        #Esto para poder tener una distribución de valores de integrales.
        
        integral_n = trapezoid(y_SI + np.random.normal(scale=abs(y_inc)),x_SI)
        
        integrales = np.append(integrales, integral_n)
    
    #Se halla el promedio de los valores y la incertidumbre. La incertidumbre es dividida por
    #la raíz cuadrada de los valores de intensidad debido a razones estadisticas.
    
    integral_prom = integrales.mean()
    integral_inc = integrales.std() / np.sqrt(len(y_SI))
    
    #Y se imprimen los valores, los cuales son MUY pequeños gracias a la conversión de unidades.
    
    print(f'1.d) Energía total radiada: {integral_prom} \u00B1 {integral_inc} J')
    
    return integrales

def histograma_integrales_pdf(array):
        
    #Se grafican los valores en un histograma para observar la variación y el pdf.
    
    with PdfPages('Histograma.pdf') as pdf:
        
        plt.figure(figsize=(6.5, 5))
        plt.hist(array)
        plt.title('Histograma de la integral')
        pdf.savefig()
        plt.close()
        
#histograma_integrales_pdf(integral(picos_y_espectro(limpieza())))

#Parte 2


def procesar_linea(linea):
    linea_corregida = re.sub(r'(?<=[0-9])(?=-?\d+\.\d+)', ' ', linea)

    numeros = re.findall(r'-?\d+\.\d+', linea_corregida)
    return list(map(float, numeros))
def leer_dataframe(archivo, columnas):
    data_procesada = []
    with open(archivo, 'r') as f:
        for linea in f:
           
            numeros = procesar_linea(linea.strip())
            data_procesada.append(numeros)
    return pd.DataFrame(data_procesada, columns=columnas)
archivo = "hysteresis.dat" 
columnas = ["Tiempo", "Columna1", "Columna2"]
df = leer_dataframe(archivo, columnas)
print(df)




df.columns = ['Tiempo', 'Campo Externo', 'Campo Interno']
plt.figure(figsize=(10, 6))

# Graficar las dos variables en el eje y frente al tiempo (eje x)
plt.plot(df['Tiempo'], df['Campo Externo'], label='B', marker='o')
plt.plot(df['Tiempo'], df['Campo Interno'], label='H', marker='s')

# Agregar etiquetas y título
plt.xlabel('Tiempo', fontsize=12)
plt.ylabel('Valor', fontsize=12)

# Mostrar leyenda
plt.legend()

# Habilitar cuadrícula para mejor visualización
plt.grid(True, linestyle='--', alpha=0.6)

# Mostrar la gráfica
plt.show()


# Extraer los datos
tiempo = df['Tiempo'].values  # Tiempo (columna 0)
señal = df['Campo Externo'].values  # Señal (columna 1)

# Calcular el intervalo de tiempo (suponiendo que los datos estén uniformemente espaciados)
dt = np.mean(np.diff(tiempo))  # Diferencia promedio entre puntos de tiempo

# Aplicar la Transformada Rápida de Fourier (FFT)
n = len(señal)  # Número de puntos en la señal
frecuencias = fftfreq(n, d=dt)  # Frecuencias correspondientes
fft_magnitud = np.abs(fft(señal))  # Magnitud de la FFT
# Filtrar solo las frecuencias positivas
frecuencias_positivas = frecuencias[frecuencias > 0]
fft_magnitud_positiva = fft_magnitud[frecuencias > 0]

# Encontrar la frecuencia dominante
frecuencia_dominante = frecuencias_positivas[np.argmax(fft_magnitud_positiva)]

# Imprimir el resultado
print(f"2.b.) La frecuencia dominante es aproximadamente {frecuencia_dominante:.2f} Hz", "al ver la grafica me vino a la mente lo que se hizo en lab de ondas \n cuando nos hablaron de la FFT  como herramienta para saber las frecuencias de graficas, luego solo fue buscar la \n libreria adecuada que tuviera la fft y usar argmax para tomar la frecuencia asociada al maximo")

# Graficar la FFT para visualizar
plt.figure(figsize=(10, 6))
plt.plot(frecuencias_positivas, fft_magnitud_positiva, label='Espectro de la señal')
plt.axvline(frecuencia_dominante, color='r', linestyle='--', label=f'Frecuencia Dominante: {frecuencia_dominante:.2f} Hz')
plt.xlabel('Frecuencia (Hz)', fontsize=12)
plt.ylabel('Amplitud', fontsize=12)
plt.title('Análisis de Frecuencia (FFT)', fontsize=14)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()


B= np.array(df['Campo Externo'].values)
H = np.array(df['Campo Interno'].values)
area = np.trapezoid(H, B)
plt.figure(figsize=(10, 6))

# Graficar las dos variables en el eje y frente al tiempo (eje x)
plt.plot(B,H, label='B', marker='o')


# Agregar etiquetas y título
plt.xlabel('B', fontsize=12)
plt.ylabel('H', fontsize=12)

# Mostrar leyenda
plt.legend()

# Habilitar cuadrícula para mejor visualización
plt.grid(True, linestyle='--', alpha=0.6)

# Mostrar la gráfica
plt.show()
print(f"2c) el valor de la pérdida de energía por ciclo es: {area:.4f} J/m^3")

